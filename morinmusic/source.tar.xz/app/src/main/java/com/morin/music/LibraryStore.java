package com.morin.music;

import android.content.Context;
import android.net.Uri;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/** Private catalogue of user-imported files; recordings remain in Android's MediaStore. */
public final class LibraryStore {
    private LibraryStore() {}
    private static final String PREFS = "morin_library";
    private static final String KEY = "entries";

    public static class Entry {
        public final Uri uri;
        public final String name;
        public final String mime;
        public Entry(Uri uri, String name, String mime) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
        }
        public boolean video() { return mime.startsWith("video/"); }
    }

    public static synchronized ArrayList<Entry> all(Context context) {
        ArrayList<Entry> list = new ArrayList<>();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try {
            JSONArray json = new JSONArray(raw);
            for (int i = 0; i < json.length(); i++) {
                JSONObject row = json.getJSONObject(i);
                list.add(new Entry(Uri.parse(row.getString("uri")), row.getString("name"), row.optString("mime", "audio/*")));
            }
        } catch (Exception ignored) { }
        return list;
    }

    private static void save(Context context, ArrayList<Entry> list) {
        JSONArray json = new JSONArray();
        for (Entry e : list) {
            JSONObject row = new JSONObject();
            try {
                row.put("uri", e.uri.toString());
                row.put("name", e.name);
                row.put("mime", e.mime);
                json.put(row);
            } catch (Exception ignored) { }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json.toString()).apply();
    }

    public static synchronized void add(Context context, Entry entry) {
        ArrayList<Entry> list = all(context);
        for (Entry e : list) if (e.uri.equals(entry.uri)) return;
        list.add(entry);
        save(context, list);
    }

    public static synchronized void remove(Context context, int index) {
        ArrayList<Entry> list = all(context);
        if (index >= 0 && index < list.size()) { list.remove(index); save(context, list); }
    }
}
