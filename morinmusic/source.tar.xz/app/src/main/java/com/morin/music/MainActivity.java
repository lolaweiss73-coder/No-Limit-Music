package com.morin.music;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Personal offline audio/video collection and explicit user-initiated screen capture. */
public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 210, ASK_CAPTURE = 211, ASK_AUDIO = 212, ASK_NOTIFICATIONS = 213;
    private static final int NAVY = Color.rgb(19, 29, 45), BLUE = Color.rgb(51, 95, 145);
    private LinearLayout songs;
    private TextView status;
    private SurfaceView video;
    private PlaybackService playback;
    private boolean bound = false;
    private boolean bindingStarted = false;
    private MediaProjectionManager projectionManager;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder binder) {
            playback = ((PlaybackService.LocalBinder) binder).getService();
            bound = true;
            if (video.getHolder().getSurface().isValid()) playback.setVideoSurface(video.getHolder());
        }
        @Override public void onServiceDisconnected(ComponentName n) { bound = false; playback = null; }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(NAVY);
        root.setPadding(18, 18, 18, 28);
        scroll.addView(root);
        setContentView(scroll);

        TextView heading = text("♪ MORIN MUSIC", 27, Color.WHITE);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        TextView subtitle = text("המוזיקה שלך. גם בלי אינטרנט. גם כשהמסך כבוי.", 15, 0xffc4d6e9);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        status = text("קבצי המוזיקה והקליפים נשמרים במכשיר שלך", 13, Color.LTGRAY);
        root.addView(status);

        video = new SurfaceView(this);
        video.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(-1, dp(200));
        videoParams.topMargin = dp(14);
        root.addView(video, videoParams);
        video.getHolder().addCallback(new SurfaceHolder.Callback() {
            public void surfaceCreated(SurfaceHolder h) { if (bound) playback.setVideoSurface(h); }
            public void surfaceChanged(SurfaceHolder h, int f, int w, int he) { }
            public void surfaceDestroyed(SurfaceHolder h) { if (bound) playback.setVideoSurface(null); }
        });

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        root.addView(controls);
        control(controls, "⏮", () -> action(PlaybackService.PREVIOUS));
        control(controls, "⏯", () -> action(PlaybackService.TOGGLE));
        control(controls, "⏭", () -> action(PlaybackService.NEXT));
        control(controls, "⏹", () -> action(PlaybackService.STOP));

        button(root, "＋  ייבוא מוזיקה / קליפים מהמכשיר", this::pickFiles);
        button(root, "●  התחלת הקלטת מסך", this::askToRecord);
        button(root, "■  סיום הקלטה ושמירת MP4", () -> {
            Intent i = new Intent(this, ScreenRecorderService.class).setAction(ScreenRecorderService.STOP);
            startService(i);
            Toast.makeText(this, "מסיים הקלטה ושומר קובץ…", Toast.LENGTH_LONG).show();
        });
        button(root, "▶  פתיחת קליפ ב־YouTube", this::openYoutube);

        root.addView(text("הספרייה שלי", 21, Color.WHITE));
        songs = new LinearLayout(this);
        songs.setOrientation(LinearLayout.VERTICAL);
        root.addView(songs);
        button(root, "רענון הספרייה", this::refresh);
        root.addView(text("20 השירים שבחרנו · חיפוש קליפ לפי שם", 18, 0xffd6e9ff));
        loadPlaylist(root);
        root.addView(text("חשוב: הקלטת המסך נעשית באישור מערכת ההפעלה. שמע פנימי נלכד רק מאפליקציות שמרשות זאת. הסרטונים נשמרים מקומית, בלי עקיפת מנגנוני הגנה.", 13, 0xffcbd5e1));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, ASK_NOTIFICATIONS);
        refresh();
    }

    private TextView text(String t, int size, int color) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(dp(5), dp(9), dp(5), dp(9));
        return v;
    }
    private void button(LinearLayout parent, String title, Runnable run) {
        Button b = new Button(this);
        b.setText(title); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        parent.addView(b, p); b.setOnClickListener(v -> run.run());
    }
    private void control(LinearLayout parent, String label, Runnable run) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextSize(21); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));
        parent.addView(b, new LinearLayout.LayoutParams(0, dp(60), 1f));
        b.setOnClickListener(v -> run.run());
    }
    private int dp(int n) { return (int) (getResources().getDisplayMetrics().density * n); }
    private void pickFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, PICK_MEDIA);
    }
    private void askToRecord() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            new AlertDialog.Builder(this).setTitle("הרשאת שמע")
                .setMessage("כדי לנסות להקליט גם שמע פנימי, יש לאשר הרשאת מיקרופון. לא נקליט מהמיקרופון: הרשאה זו נדרשת ל־AudioPlaybackCapture. אם מקור המדיה חוסם לכידת שמע, ההקלטה תהיה ללא שמע.")
                .setPositiveButton("המשך", (d, w) -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, ASK_AUDIO))
                .setNegativeButton("וידאו בלבד", (d, w) -> beginCapture()).show();
        } else beginCapture();
    }
    private void beginCapture() {
        try { startActivityForResult(projectionManager.createScreenCaptureIntent(), ASK_CAPTURE); }
        catch (Exception e) { Toast.makeText(this, "לא ניתן להפעיל לכידת מסך: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(req, permissions, results);
        if (req == ASK_AUDIO) beginCapture();
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == ASK_CAPTURE) {
            if (result == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenRecorderService.class);
                service.setAction(ScreenRecorderService.START);
                service.putExtra(ScreenRecorderService.CODE, result);
                service.putExtra(ScreenRecorderService.DATA, data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                Toast.makeText(this, "הקלטה מתחילה. כעת פתח את הקליפ הרצוי.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (req == PICK_MEDIA && result == RESULT_OK && data != null) {
            int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (data.getData() != null) importUri(data.getData(), flags);
            ClipData selected = data.getClipData();
            if (selected != null) for (int i = 0; i < selected.getItemCount(); i++)
                importUri(selected.getItemAt(i).getUri(), flags);
            refresh();
        }
    }
    private void importUri(Uri uri, int flags) {
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) { }
        String name = uri.getLastPathSegment();
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        String mime = getContentResolver().getType(uri);
        if (mime == null) mime = name != null && name.toLowerCase().endsWith(".mp4") ? "video/mp4" : "audio/*";
        LibraryStore.add(this, new LibraryStore.Entry(uri, name == null ? "ללא שם" : name, mime));
    }
    private void refresh() {
        if (songs == null) return;
        songs.removeAllViews();
        ArrayList<LibraryStore.Entry> all = LibraryStore.all(this);
        String last = getSharedPreferences("morin_state", MODE_PRIVATE).getString("last_recording", "");
        status.setText(all.size() + " קבצים בספרייה המקומית" + (last.isEmpty() ? "" : "\n" + last));
        if (all.isEmpty()) songs.addView(text("אין קבצים עדיין. ייבא קובצי אודיו או וידאו, או הקלט קליפ.", 14, Color.WHITE));
        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            LibraryStore.Entry e = all.get(i);
            LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
            songs.addView(line);
            TextView name = text((e.video() ? "🎬 " : "🎵 ") + e.name, 15, Color.WHITE);
            line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            Button play = new Button(this); play.setText("נגן"); play.setAllCaps(false);
            line.addView(play); play.setOnClickListener(v -> play(idx));
            Button remove = new Button(this); remove.setText("✕"); remove.setAllCaps(false);
            line.addView(remove); remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("להסיר מהספרייה? הקובץ עצמו לא יימחק.")
                .setPositiveButton("הסר", (d, w) -> { LibraryStore.remove(this, idx); refresh(); })
                .setNegativeButton("ביטול", null).show());
        }
    }
    private void play(int index) {
        Intent i = new Intent(this, PlaybackService.class).setAction(PlaybackService.PLAY_INDEX)
            .putExtra(PlaybackService.EXTRA_INDEX, index);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    private void action(String action) {
        startService(new Intent(this, PlaybackService.class).setAction(action));
    }
    private void openYoutube() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("הדבק קישור לקליפ או שם שיר");
        new AlertDialog.Builder(this).setTitle("פתיחת קליפ ב־YouTube").setView(input)
            .setPositiveButton("פתח", (d, w) -> {
                String typed = input.getText().toString().trim();
                if (typed.isEmpty()) return;
                Uri maybe = Uri.parse(typed);
                String host = maybe.getHost();
                boolean isYoutubeLink = ("https".equals(maybe.getScheme()) || "http".equals(maybe.getScheme()))
                    && host != null && (host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be"));
                String url = isYoutubeLink ? typed : "https://www.youtube.com/results?search_query=" + Uri.encode(typed);
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            })
            .setNegativeButton("ביטול", null).show();
    }
    private void loadPlaylist(LinearLayout root) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open("playlist.csv"), StandardCharsets.UTF_8))) {
            String line; int count = 0;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;
                line = line.replace("\uFEFF", "");
                String[] cells = line.replace("\"", "").split(",", -1);
                if (cells.length < 2 || cells[0].equalsIgnoreCase("title") || cells[0].equalsIgnoreCase("name")) continue;
                // The bundle contains columns Title,Artist. Handle extras, ignore numbering headers.
                String title = cells[0], artist = cells[1];
                if (title.equalsIgnoreCase("Song") || title.equalsIgnoreCase("Track")) continue;
                count++;
                String query = title + " " + artist;
                TextView item = text("♪ " + title + " · " + artist, 14, 0xffd6e9ff);
                root.addView(item);
                item.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))));
            }
        } catch (Exception ignored) { }
    }
    @Override protected void onStart() {
        super.onStart();
        bindingStarted = bindService(new Intent(this, PlaybackService.class), connection, BIND_AUTO_CREATE);
    }
    @Override protected void onResume() { super.onResume(); if (songs != null) refresh(); }
    @Override protected void onStop() {
        if (bindingStarted) { unbindService(connection); bindingStarted = false; }
        bound = false; playback = null;
        super.onStop();
    }
}
