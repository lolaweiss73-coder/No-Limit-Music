package com.morin.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import java.util.ArrayList;

/** Foreground local-file media player. Audio continues when the screen is off. */
public class PlaybackService extends Service {
    public static final String PLAY_INDEX = "com.morin.music.PLAY_INDEX";
    public static final String TOGGLE = "com.morin.music.TOGGLE";
    public static final String NEXT = "com.morin.music.NEXT";
    public static final String PREVIOUS = "com.morin.music.PREVIOUS";
    public static final String STOP = "com.morin.music.STOP";
    public static final String EXTRA_INDEX = "index";
    private static final int NOTIFICATION_ID = 111;
    private static final String CHANNEL = "morin_audio";

    private final IBinder binder = new LocalBinder();
    private MediaPlayer player;
    private MediaSession session;
    private SurfaceHolder holder;
    private int index = -1;
    private boolean preparing = false;
    private boolean activelyPlaying = false;

    public class LocalBinder extends Binder {
        public PlaybackService getService() { return PlaybackService.this; }
    }
    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "ניגון מוזיקה", NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "MorinMusicSession");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onStop() { stopPlayback(); }
        });
        session.setActive(true);
        updateState();
    }

    public void setVideoSurface(SurfaceHolder surface) {
        holder = surface;
        if (player != null) {
            try { player.setDisplay(holder); } catch (Exception ignored) { }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (PLAY_INDEX.equals(action)) playAt(intent.getIntExtra(EXTRA_INDEX, -1));
            else if (TOGGLE.equals(action)) { if (activelyPlaying || preparing) pause(); else resume(); }
            else if (NEXT.equals(action)) next();
            else if (PREVIOUS.equals(action)) previous();
            else if (STOP.equals(action)) stopPlayback();
        }
        return START_NOT_STICKY;
    }

    private void playAt(int requested) {
        ArrayList<LibraryStore.Entry> all = LibraryStore.all(this);
        if (requested < 0 || requested >= all.size()) return;
        releasePlayer();
        index = requested;
        getSharedPreferences("morin_state", MODE_PRIVATE).edit().putInt("index", index).apply();
        LibraryStore.Entry entry = all.get(index);
        try {
            player = new MediaPlayer();
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            if (holder != null) player.setDisplay(holder);
            player.setDataSource(this, entry.uri);
            player.setOnPreparedListener(mp -> {
                preparing = false;
                mp.start();
                activelyPlaying = true;
                publish();
            });
            player.setOnCompletionListener(mp -> next());
            player.setOnErrorListener((mp, what, extra) -> {
                preparing = false;
                activelyPlaying = false;
                publish();
                return true;
            });
            preparing = true;
            publish();
            player.prepareAsync();
        } catch (Exception error) {
            preparing = false;
            activelyPlaying = false;
            releasePlayer();
            publish();
        }
    }

    private void next() {
        ArrayList<LibraryStore.Entry> all = LibraryStore.all(this);
        if (!all.isEmpty()) playAt((index + 1 + all.size()) % all.size());
    }
    private void previous() {
        ArrayList<LibraryStore.Entry> all = LibraryStore.all(this);
        if (!all.isEmpty()) playAt((index - 1 + all.size()) % all.size());
    }
    private void pause() {
        preparing = false;
        try { if (player != null && player.isPlaying()) player.pause(); } catch (Exception ignored) { }
        activelyPlaying = false;
        publish();
    }
    private void resume() {
        if (player == null) {
            int saved = getSharedPreferences("morin_state", MODE_PRIVATE).getInt("index", 0);
            playAt(saved);
            return;
        }
        try {
            player.start();
            activelyPlaying = true;
            publish();
        } catch (Exception ignored) { }
    }
    private void stopPlayback() {
        releasePlayer();
        activelyPlaying = false;
        preparing = false;
        publish();
        stopSelf();
    }
    private void releasePlayer() {
        if (player != null) {
            try { player.reset(); player.release(); } catch (Exception ignored) { }
            player = null;
        }
        preparing = false;
        activelyPlaying = false;
    }

    private String currentTitle() {
        ArrayList<LibraryStore.Entry> all = LibraryStore.all(this);
        return index >= 0 && index < all.size() ? all.get(index).name : "מורין מיוזיק";
    }
    private void updateState() {
        int state = activelyPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        long position = 0;
        try { if (player != null && !preparing) position = player.getCurrentPosition(); } catch (Exception ignored) { }
        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                        PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT |
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP)
            .setState(state, position, activelyPlaying ? 1f : 0f, SystemClock.elapsedRealtime())
            .build());
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, currentTitle()).build());
    }
    private PendingIntent actionIntent(String action, int requestCode) {
        Intent intent = new Intent(this, PlaybackService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Action prev = new Notification.Action.Builder(android.R.drawable.ic_media_previous, "הקודם", actionIntent(PREVIOUS, 1)).build();
        Notification.Action play = new Notification.Action.Builder(
            activelyPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
            activelyPlaying ? "השהה" : "נגן", actionIntent(TOGGLE, 2)).build();
        Notification.Action next = new Notification.Action.Builder(android.R.drawable.ic_media_next, "הבא", actionIntent(NEXT, 3)).build();
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(currentTitle())
            .setContentText("מורין מיוזיק · נגן אישי")
            .setContentIntent(open)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2))
            .addAction(prev).addAction(play).addAction(next)
            .setOngoing(activelyPlaying)
            .build();
    }
    private void publish() {
        updateState();
        if (activelyPlaying || preparing) {
            startForeground(NOTIFICATION_ID, notification());
        } else {
            stopForeground(STOP_FOREGROUND_DETACH);
            getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification());
        }
    }
    @Override public void onDestroy() {
        releasePlayer();
        if (session != null) { session.setActive(false); session.release(); }
        getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
        super.onDestroy();
    }
}
