package com.morin.music;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Captures only after Android's MediaProjection consent dialog. Internal-audio capture
 * uses the Android 10+ public AudioPlaybackCapture API. Other applications can opt out;
 * in that case the recorded video may be silent. No DRM or platform protections bypassed.
 */
public class ScreenRecorderService extends Service {
    public static final String START = "com.morin.music.RECORD_START";
    public static final String STOP = "com.morin.music.RECORD_STOP";
    public static final String CODE = "resultCode";
    public static final String DATA = "resultData";
    private static final int NOTICE_ID = 222;
    private static final String CHANNEL = "morin_record";
    private final AtomicBoolean recording = new AtomicBoolean(false);
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec videoEncoder, audioEncoder;
    private AudioRecord audioRecord;
    private MediaMuxer muxer;
    private Surface encodeSurface;
    private ParcelFileDescriptor outputFd;
    private Uri outputUri;
    private int videoTrack = -1, audioTrack = -1;
    private boolean muxerStarted;
    private boolean gotAudio;
    private boolean hasWrittenVideo;
    private long firstVideoPtsUs = -1, firstAudioPtsUs = -1;
    private long lastVideoPtsUs = -1, lastAudioPtsUs = -1;
    private Thread worker;

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "הקלטת מסך", NotificationManager.IMPORTANCE_LOW));
    }
    private Notification recordingNotification() {
        Intent stop = new Intent(this, ScreenRecorderService.class).setAction(STOP);
        PendingIntent pi = PendingIntent.getService(this, 30, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 31,
            new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("מורין מיוזיק · הקלטת מסך")
            .setContentText("לסיום ושמירה לחץ עצור")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentIntent(open)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "עצור ושמור", pi).build())
            .setOngoing(true).build();
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) return START_NOT_STICKY;
        if (STOP.equals(intent.getAction())) {
            recording.set(false);
            if (worker == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (START.equals(intent.getAction()) && recording.compareAndSet(false, true)) {
            // Must enter a mediaProjection foreground service before obtaining the projection.
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(NOTICE_ID, recordingNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(NOTICE_ID, recordingNotification());
            int code = intent.getIntExtra(CODE, -1);
            Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(DATA, Intent.class) : intent.getParcelableExtra(DATA);
            if (code == -1 || data == null) { recording.set(false); stopSelf(); return START_NOT_STICKY; }
            final Intent authorizedData = data;
            worker = new Thread(() -> capture(code, authorizedData), "morin-screen-capture");
            worker.start();
        }
        return START_NOT_STICKY;
    }
    private void capture(int resultCode, Intent resultData) {
        boolean success = false;
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Screen permission was not granted");
            // Android 14+ requires this callback before createVirtualDisplay.
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { recording.set(false); }
            }, new Handler(Looper.getMainLooper()));

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            int width = dm.widthPixels, height = dm.heightPixels;
            float shrink = Math.min(1.0f, 1920f / Math.max(width, height));
            width = Math.max(2, ((int)(width * shrink) / 2) * 2);
            height = Math.max(2, ((int)(height * shrink) / 2) * 2);

            String filename = "MorinMusic_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MorinMusic");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            outputUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (outputUri == null) throw new IllegalStateException("Cannot create recording file");
            outputFd = getContentResolver().openFileDescriptor(outputUri, "w");
            if (outputFd == null) throw new IllegalStateException("Cannot open recording file");
            muxer = new MediaMuxer(outputFd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(1_500_000, width * height * 3));
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encodeSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            // Build audio capture only when microphone runtime permission exists. Despite
            // the permission name, this recorder uses playback-capture, not the microphone.
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                try {
                    AudioPlaybackCaptureConfiguration captureConfig = new AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .build();
                    int buffer = Math.max(16_384, AudioRecord.getMinBufferSize(44100,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) * 2);
                    AudioFormat pcm = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
                    audioRecord = new AudioRecord.Builder().setAudioFormat(pcm)
                        .setBufferSizeInBytes(buffer)
                        .setAudioPlaybackCaptureConfig(captureConfig).build();
                    if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("AudioRecord init error");
                    MediaFormat format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 1);
                    format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                    format.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
                    audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                    audioEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                    audioEncoder.start();
                    audioRecord.startRecording();
                    if (audioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("AudioRecord start error");
                    gotAudio = true;
                } catch (Exception audioFailure) {
                    gotAudio = false;
                    if (audioRecord != null) { try { audioRecord.release(); } catch (Exception ignored) {} audioRecord = null; }
                    if (audioEncoder != null) { try { audioEncoder.stop(); } catch (Exception ignored) {} audioEncoder.release(); audioEncoder = null; }
                }
            }
            virtualDisplay = projection.createVirtualDisplay("MorinMusicCapture", width, height, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, encodeSurface, null, null);
            long audioSamples = 0;
            while (recording.get()) {
                if (gotAudio) {
                    int inputId = audioEncoder.dequeueInputBuffer(0);
                    if (inputId >= 0) {
                        ByteBuffer input = audioEncoder.getInputBuffer(inputId);
                        if (input != null) {
                            input.clear();
                            int requested = Math.min(4096, input.remaining());
                            int read = audioRecord.read(input, requested, AudioRecord.READ_NON_BLOCKING);
                            if (read > 0) {
                                long pts = audioSamples * 1_000_000L / 44100L;
                                audioSamples += read / 2L;
                                audioEncoder.queueInputBuffer(inputId, 0, read, pts, 0);
                            } else audioEncoder.queueInputBuffer(inputId, 0, 0, audioSamples * 1_000_000L / 44100L, 0);
                        }
                    }
                }
                drain(videoEncoder, true, false);
                if (gotAudio) drain(audioEncoder, false, false);
                SystemClock.sleep(12);
            }
            if (videoEncoder != null) videoEncoder.signalEndOfInputStream();
            if (gotAudio && audioEncoder != null) {
                int id = audioEncoder.dequeueInputBuffer(100_000);
                if (id >= 0) audioEncoder.queueInputBuffer(id, 0, 0, audioSamples * 1_000_000L / 44100L, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            for (int i = 0; i < 60; i++) {
                drain(videoEncoder, true, true);
                if (gotAudio) drain(audioEncoder, false, true);
                SystemClock.sleep(12);
            }
            success = muxerStarted && hasWrittenVideo;
        } catch (Exception error) {
            getSharedPreferences("morin_state", MODE_PRIVATE).edit()
                .putString("last_recording", "שגיאת הקלטה: " + error.getMessage()).apply();
        } finally {
            recording.set(false);
            cleanup(success);
            stopSelf();
        }
    }
    private void drain(MediaCodec encoder, boolean video, boolean end) {
        if (encoder == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        for (int count = 0; count < (end ? 16 : 8); count++) {
            int result = encoder.dequeueOutputBuffer(info, end ? 10_000 : 0);
            if (result == MediaCodec.INFO_TRY_AGAIN_LATER) break;
            if (result == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (video) videoTrack = muxer.addTrack(encoder.getOutputFormat());
                else audioTrack = muxer.addTrack(encoder.getOutputFormat());
                if (videoTrack >= 0 && (!gotAudio || audioTrack >= 0) && !muxerStarted) {
                    muxer.start(); muxerStarted = true;
                }
            } else if (result >= 0) {
                ByteBuffer out = encoder.getOutputBuffer(result);
                if (out != null && info.size > 0 && muxerStarted) {
                    out.position(info.offset); out.limit(info.offset + info.size);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        long first = video ? firstVideoPtsUs : firstAudioPtsUs;
                        if (first < 0) { first = info.presentationTimeUs;
                            if (video) firstVideoPtsUs = first; else firstAudioPtsUs = first; }
                        long last = video ? lastVideoPtsUs : lastAudioPtsUs;
                        long normalizedPts = Math.max(0, info.presentationTimeUs - first);
                        info.presentationTimeUs = Math.max(normalizedPts, last < 0 ? 0 : last + 1);
                        if (video) lastVideoPtsUs = info.presentationTimeUs; else lastAudioPtsUs = info.presentationTimeUs;
                        muxer.writeSampleData(video ? videoTrack : audioTrack, out, info);
                        if (video) hasWrittenVideo = true;
                    }
                }
                encoder.releaseOutputBuffer(result, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }
    private void cleanup(boolean success) {
        if (audioRecord != null) { try { audioRecord.stop(); } catch (Exception ignored) {} audioRecord.release(); audioRecord = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) {} projection = null; }
        if (encodeSurface != null) { encodeSurface.release(); encodeSurface = null; }
        if (videoEncoder != null) { try { videoEncoder.stop(); } catch (Exception ignored) {} videoEncoder.release(); videoEncoder = null; }
        if (audioEncoder != null) { try { audioEncoder.stop(); } catch (Exception ignored) {} audioEncoder.release(); audioEncoder = null; }
        if (muxer != null) {
            try { if (muxerStarted) muxer.stop(); else success = false; } catch (Exception e) { success = false; }
            try { muxer.release(); } catch (Exception ignored) {}
            muxer = null;
        }
        if (outputFd != null) { try { outputFd.close(); } catch (Exception ignored) {} outputFd = null; }
        if (outputUri != null) {
            if (success) {
                ContentValues finished = new ContentValues(); finished.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(outputUri, finished, null, null);
                LibraryStore.add(this, new LibraryStore.Entry(outputUri, "הקלטה " + new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date()), "video/mp4"));
                getSharedPreferences("morin_state", MODE_PRIVATE).edit().putString("last_recording", "ההקלטה נשמרה בתיקיית Movies/MorinMusic" + (gotAudio ? " · שמע פנימי אם המקור אפשר זאת" : " · ללא שמע")).apply();
            } else {
                getContentResolver().delete(outputUri, null, null);
                getSharedPreferences("morin_state", MODE_PRIVATE).edit().putString("last_recording", "ההקלטה נכשלה או נעצרה לפני שנשמר וידאו").apply();
            }
            outputUri = null;
        }
    }
    @Override public void onDestroy() {
        recording.set(false);
        super.onDestroy();
    }
}
